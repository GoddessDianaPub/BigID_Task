## Introduction

This chart bootstraps BigID App deployment on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Installing the Chart

To install the chart with the release name `doc-classifiers-generator`:

```$ helm install doc-classifiers-generator . --namespace [NAMESPACE]```

## Upgrding the chart

```$ helm upgrade doc-classifiers-generator . --namespace [NAMESPACE]```

## Uninstalling the Chart

```$ helm uninstall doc-classifiers-generator --namespace [NAMESPACE]```

## Rollback the Chart

```$ helm rollback doc-classifiers-generator [REVISION] --namespace [NAMESPACE]```
